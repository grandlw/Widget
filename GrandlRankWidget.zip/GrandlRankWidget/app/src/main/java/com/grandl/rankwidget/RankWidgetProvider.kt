package com.grandl.rankwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import androidx.work.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class RankWidgetProvider : AppWidgetProvider() {
    override fun onEnabled(context: Context) { schedule(context); enqueueNow(context) }
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { enqueueNow(context) }
    companion object {
        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<RankWorker>(24, TimeUnit.HOURS).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("daily-rank", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
        fun enqueueNow(context: Context) = WorkManager.getInstance(context).enqueue(OneTimeWorkRequestBuilder<RankWorker>().build())
        fun render(context: Context, d: RankData) {
            val v = RemoteViews(context.packageName, R.layout.rank_widget)
            v.setTextViewText(R.id.solo, "Solo/Duo: ${d.solo}")
            v.setTextViewText(R.id.record, d.record)
            v.setTextViewText(R.id.flex, "Flex: ${d.flex}")
            v.setTextViewText(R.id.updated, "Son yenileme: " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr","TR")).format(Date()))
            val m = AppWidgetManager.getInstance(context)
            m.updateAppWidget(ComponentName(context, RankWidgetProvider::class.java), v)
        }
    }
}

class RankWorker(ctx: Context, params: WorkerParameters): Worker(ctx, params) {
    override fun doWork(): Result = try { RankWidgetProvider.render(applicationContext, RankRepository.fetch()); Result.success() } catch (_: Exception) { Result.retry() }
}
