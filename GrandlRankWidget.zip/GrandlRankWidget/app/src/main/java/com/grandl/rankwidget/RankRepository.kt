package com.grandl.rankwidget

import org.jsoup.Jsoup

data class RankData(val solo: String, val record: String, val flex: String)

object RankRepository {
    private const val URL = "https://op.gg/tr/lol/summoners/tr/grandl-wave"
    fun fetch(): RankData {
        val doc = Jsoup.connect(URL).userAgent("Mozilla/5.0 (Android) GrandlRankWidget/1.0").timeout(15000).get()
        val text = doc.body().wholeText().replace(Regex("\\s+"), " ")
        val solo = Regex("Dereceli Tek/Çift.*?((?:Iron|Bronze|Silver|Gold|Platinum|Emerald|Diamond|Master|Grandmaster|Challenger) \\d? \\d+ LP)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)
            ?: Regex("((?:Iron|Bronze|Silver|Gold|Platinum|Emerald|Diamond|Master|Grandmaster|Challenger) \\d? \\d+ LP)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1) ?: "Rank bulunamadı"
        val wl = Regex("(\\d+)G (\\d+)M Kazanma oranı (\\d+)%").find(text)
        val record = if (wl != null) "${wl.groupValues[1]}W • ${wl.groupValues[2]}L • %${wl.groupValues[3]} WR" else "W/L bulunamadı"
        val flexSection = text.substringAfter("Dereceli Esnek", "")
        val flex = Regex("((?:Iron|Bronze|Silver|Gold|Platinum|Emerald|Diamond|Master|Grandmaster|Challenger) \\d? \\d+ LP)", RegexOption.IGNORE_CASE).find(flexSection)?.groupValues?.get(1) ?: "Flex bulunamadı"
        return RankData(solo, record, flex)
    }
}
