package com.grandl.rankwidget

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        val status = findViewById<TextView>(R.id.status)
        fun refresh() { status.text="OP.GG okunuyor…"; thread { try { val d=RankRepository.fetch(); RankWidgetProvider.render(this,d); runOnUiThread { status.text="Solo/Duo: ${d.solo}\n${d.record}\nFlex: ${d.flex}" } } catch(e:Exception) { runOnUiThread { status.text="Yenileme hatası: ${e.message}" } } } }
        findViewById<Button>(R.id.refresh).setOnClickListener { refresh() }
        RankWidgetProvider.schedule(this); refresh()
    }
}
